import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./MainPageComponents/Layout";
import Home from "./MainPageComponents/Home";
import ManagingStakeholders from "./MainPageComponents/ManagingStakeholders";
import LoginPage from "./MainPageComponents/LoginPage";
import NoPage from "./MainPageComponents/NoPage";
import 'bootstrap/dist/css/bootstrap.min.css';
import EffectiveNego from './MainPageComponents/LearnerFlowComponents/EffectiveNego';
import OnlineApplication from './MainPageComponents/OnlineApplication';
import OnlineAppPartTwo from './MainPageComponents/OnlineAppPartTwo';
import LearningObj from './MainPageComponents/DistributiveNego/LearningObj';


export default function App() {
  return (

    
    <BrowserRouter>
    <TransitionGroup>
    <CSSTransition timeout={timeout} className="pageSlider" mountOnEnter={false} unomuntOnExit={true}> 
    <Switch location={location}>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="ManagingStakeholders" element={<ManagingStakeholders />} />
          <Route path="LoginPage" element={<LoginPage />} />
          <Route path="OnlineApplication" element={<OnlineApplication/>}/>
          <Route path="EffectiveNego" element={<EffectiveNego/>} />
          <Route path="OnlineAppPartTwo" element={<OnlineAppPartTwo />} />
          <Route path="LearningObj" element={<LearningObj />} />
          <Route path="*" element={<NoPage />} />
          
          
        </Route>
      </Routes>
      </Switch>
      </CSSTransition>
    </TransitionGroup>
    </BrowserRouter>
    
  );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  
    <App />
 
);
