import { Outlet, Link } from "react-router-dom";

const Layout = () => {
  return (
    <>
      
        
        
            <Link to="/">
            Home--
            </Link>
          
        
            <Link to="/ManagingStakeholders">
            ManagingStakeholders--
            </Link>
          
        
            <Link to="/LoginPage">
            LoginPage--
            </Link>
          
        
            
            <Link to="/OnlineApplication">
            OnlineApplication--
            </Link>
        

            <Link to="/OnlineAppPartTwo">
            OnlineAppPartTwo--
            </Link>
            
            <Link to="/EffectiveNego">
            Effective Negotiation--
            </Link>
            <Link to="/LearningObj">
            LearningObj--
            </Link>


            


           
      <Outlet />
    </>
  )
};

export default Layout;