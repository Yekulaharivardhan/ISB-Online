import React from 'react';
import LandNavBar from './LandingPage/LandNavbar';
import CardMain from './LandingPage/CardMain';
import JoinOurCourse from './LandingPage/JoinOurCourse';
import { Container } from 'react-bootstrap';
import WelcomeCourse from './LandingPage/WelcomeCourse';
import CourseCardsPtwo from './LandingPage/CourseCardsPtwo';
import Practice from './LandingPage/practice';
import ISBOnlineAparttitl from './LandingPage/ISBOnlineAparttitl';
import LearningTrack from './LandingPage/LearningTracks/LearningTrack';
import LearningTrackText from './LandingPage/LearningTracks/LearningTrackText';
import BusinessStrategy from './BusinessStrategy/BusinessStrategy';



const Home = () => {
    return (
    
    <>
    {/* <Practice/> */}
    <LandNavBar/>
     <Container>
    <WelcomeCourse/>
    <JoinOurCourse/>
    <CardMain/>
    <ISBOnlineAparttitl/>
    
    <CourseCardsPtwo/>
<LearningTrackText/>
    <LearningTrack/>
    <BusinessStrategy/>
    </Container>
    
</>

)

  };
  
  export default Home;