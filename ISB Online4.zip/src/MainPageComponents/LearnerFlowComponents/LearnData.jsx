const Learndata = {
    Learn: [
      {
        id: 1,
        img:"./images/Polygon.png",
        title: "Introduction to Negotiation Analysis",
        score:"_/10",
        lessionstatus:"Restart Lession"
      },
      {
        id: 2,
        img:"./images/PolygonPurp.png",
        title: "Negotiation Activity on ISB.Town",
         score:"_/100",
        lessionstatus:""
      },
      {
        id: 3,
        img:"./images/PolygonPurp.png",
        title: "Reading Materials",
         score:"_/45",
        lessionstatus:"Start Lession"
      },
      {
        id: 4,
        img:"./images/PolygonPurp.png",
        title: "Quiz",
         score:"_/100",
        lessionstatus:""
      },
    
    
    
    
    ]
    }
    export default Learndata
    