import React from 'react';
import useCollapse from 'react-collapsed';
import ModFourData from './ModFourData';

const Moduletxt = ["Introduction to Disputes","Dispute Resolution Procedures","Quiz","Reading Materials"]

const C= (<i className="fa-solid fa-chevron-up"></i>)
const E = (<i className="fa-solid fa-chevron-down"></i>)




export function ModuleFour() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="Module0 h3"><img src="./images/FullCircle.png" alt="" style={{display:"flex",margin:"10px 0 -47px 0px",}}/>
        <div className="header" {...getToggleProps()}>
        
            {isExpanded ? C : E }
            <h3> Module 4: Dispute Resolution Negotiations</h3>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            <ul>
{ModFourData.ModFourData.map((m ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">
<h5 key={m.id}>
    <div className="im col-7">
    {m.title}
    </div>
    <div className="im col-1 dimond_img" style={{}}>
    <img src={m.img} alt="" style={{}} /> 
    </div>
    <p className="im col-2 score_cls" style={{}}>
    {m.score}</p>
    <div className="im col-2 lession_status" style={{}}>
    <span style={{}}> {m.lessionstatus}</span>
    </div>

     </h5>
    </div></div> 
    </>
    )})}

</ul>
   
            </div>
        </div>
    </div>

</>

    );
};

