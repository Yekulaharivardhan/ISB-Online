import React from 'react';
import useCollapse from 'react-collapsed';
import ModTwoData from './ModTwoData';

const Moduletxt = ["General Concepts of Distributive Negotiations"," Strategies of Distributive Negotiations", "Roleplay Activity on ISB.Town", "Quiz","Reflection on Distributive Negotiations Activity","Reading Materials",]

const C= (<i className="fa-solid fa-chevron-up"></i>)
const E = (<i className="fa-solid fa-chevron-down"></i>)




export function ModuleTwo() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="Module0 h3"><img src="./images/FullCircle.png" alt="" style={{display:"flex",margin:"10px 0 -47px 0px",}}/>
        <div className="header" {...getToggleProps()}>
        
            {isExpanded ? C : E }
            <h3> Module 2: Distributive Negotiations</h3>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            <ul>
{ModTwoData.ModTwoData.map((two ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">
<h5 key={two.id}>
    <div className="im col-7">
    {two.title}
    </div>
    <div className="im col-1 dimond_img" style={{}}>
    <img src={two.img} alt="" style={{}} /> 
    </div>
    <p className="im col-2 score_cls" style={{}}>
    {two.score}</p>
    <div className="im col-2 lession_status" style={{}}>
    <span style={{}}> {two.lessionstatus}</span>
    </div>

     </h5>
    </div></div> 
    </>
    )})}

</ul>
   
            </div>
        </div>
    </div>

</>

    );
};

