import React from 'react';
import "./welcomeHome.css"
// import './LandNavbar.css'
import { Container } from 'react-bootstrap';

const WelcomeCourseimg = () => {
    return (
        <>
<div className="container">

        <div className='nav_books' style={{}}>
        
    <div className='isb_welcome_and_img' style={{ }}>
    <img className='Welcome_books_img' src="./images/TopBanner.png" alt="" style={{height:"100px", width:"100%",marginTop:"110px",}}/>
    
    </div>
        </div></div>
        </>
    );
};

export default WelcomeCourseimg;