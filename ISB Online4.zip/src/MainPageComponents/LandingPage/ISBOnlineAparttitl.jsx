import React from 'react';
import "./JoinOurCourse.css"

const ISBOnlineAparttitl = () => {
    return (
        <div>
          <h3 className="join_our_crs">What Sets ISB Online Apart </h3> 
        </div>
    );
};

export default ISBOnlineAparttitl;