const data = {
    productData: [
      {
        id: 1,
        img:"./images/effectiveCommunication.jpg",
        title: "Effective Communication",
        desc: "The Accounting Fundamentals course contains basic theory, concepts, and principles of financial accounting. Professor Hariom Manchiraju will help you gain a sound understanding of the technical skills needed to analyze and understand common financial statements such as the income.",
        durtnweeks:"2 Weeks",
        durtnhrsperweek:"5-6 hours per week",
        price: 5000,
      },
      {
        id: 2,
        img:"./images/effectiveNegotiation.jpg",
        title: "Effective Negotiation",
        desc: "The Critical Thinking course is aimed at empowering you with a range of behaviours, strategies, skills, and attitudes that will improve your individual effectiveness and development as well as help you perform successfully at the workplace.",
        durtnweeks:"2 Weeks",
        durtnhrsperweek:"5-6 hours per week",
        price: 5000,
      },
      {
        id: 3,
        img:"./images/LeadingChange.jpg",
        title: "Leading Change",
        desc: "Leading People and Change is a course designed to develop and expand the essential knowledge, skills, and mindset required to lead people and teams effectively. The course will help you to learn skills required for stakeholder engagement, and techniques to drive high-performing teams and deal with change.",
        durtnweeks:"5 Weeks",
        durtnhrsperweek:"7-8 hours per week",
        price: 30000,
      },
      {
        id: 4,
        img:"./images/Managing Stakeholders.jpg",
        title: "Managing Stakeholders",
        desc: "Leading People and Change is a course designed to develop and expand the essential knowledge, skills, and mindset required to lead people and teams effectively. The course will help you to learn skills required for stakeholder engagement, and techniques to drive high-performing teams and deal with change.",
        durtnweeks:"5 Weeks",
        durtnhrsperweek:"7-8 hours per week",
        price: 30000,
      },
      {
        id: 5,
        img:"./images/LeadingTeam.jpg",
        title: "Leading Team",
        desc: "The Critical Thinking course is aimed at empowering you with a range of behaviours, strategies, skills, and attitudes that will improve your individual effectiveness and development as well as help you perform successfully at the workplace.",
        durtnweeks:"2 Weeks",
        durtnhrsperweek:"5-6 hours per week",
        price: 5000,
      },
      {
        id: 6,
        img:"./images/personalLeadership.jpg",
        title: "Personal Leadership",
        desc: "The Accounting Fundamentals course contains basic theory, concepts, and principles of financial accounting. Professor Hariom Manchiraju will help you gain a sound understanding of the technical skills needed to analyze and understand common financial statements such as the income statement and balance sheet. ",
        durtnweeks:"1 Weeks",
        durtnhrsperweek:"5-8 hours per week",
        price: 30000,
      },
    
    ]}

    export default data;