import React from 'react';
import './OnlineApplication.css'
import List from './../listofStates';
import { Row } from 'react-bootstrap/Row';
import Countries from './../ListofCountries';
import LandNavbar from './LandingPage/LandNavbar';







const Salutions = ["Mr.","Miss.","Mrs.","Other"]

const colCls = ("col-4 column_4_cls")

const inputField = (<input type="text" className="form-control" placeholder=" "/>)


const listofCountries = function(countries) {
  return <option key={countries}>{countries}</option>;
};

const listofitems = function(states) {
  return <option key={states}>{states}</option>;
};
    const OnlineApplication = () => {
      
                   
    return (
      <>
      <LandNavbar/>
    <div className="container" style={{marginTop:"130px"}}>
    
    <div className="online_applictn_form_p1">
<h3>ISBOnline Application Form - Part 1/2</h3>
<p>Welcome to the ISBOnline form. Please fill out this application form to apply to ISBOnline. Once you submit your application form, the ISBOnline Admissions team will review and confirm your applicability, and you will receive a confirmation via email. After this you can complete the payment and join the course. 
This application form has 2 sections. The first section is a text input form where you will need to fill out your person, professional and education details. The second section will require you to submit a video recording of yourself. Please note all submitted information is secured and will only be used for admissions processes, and is compliant with ISB Privacy Policies. Click here to read the Privacy Policy.</p>
    </div>
<div className="container form_field_container_cls">

<form >

<h3 style={{paddingLeft:"15.5%", paddingTop:"10px"}}>About You</h3>
<div className="row form_field_cls">
    <div className={colCls}>
    <label htmlFor="exampleInput">First Name</label>
      <input type="text" className="form-control"  placeholder=" " autoFocus/>
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">Last Name</label>
      {inputField}
    

    </div>
    {/* <div className="row  form_field_cls"> */}
    <div className={colCls}>
    <label htmlFor="exampleInput">Email</label>
      <input type="text" className="form-control" placeholder=""/>
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInputMobile">Mobile</label>
      <input type="text" maxLength="6" className="form-control" placeholder=""/>
    </div>

    
    
    <div className={colCls}>
    <label htmlFor="exampleInput" >Date of Birth</label>
      <input type="Date" className="form-control" placeholder="  " />
    </div>
    <div className="col-2 column_2_cls"  >
    <label htmlFor="exampleInput">Gender</label>

    <select className="form-select" aria-label="Default select example">
    <option>Select</option>
  <option>Male</option>
  <option>Female</option>
  <option>Other</option>
</select>
      
    </div>
    <div className="col-2 column_2_cls" style={{width:"17%",  marginRight:"25px",}}>
    <label htmlFor="exampleInput" >Pronoun</label>

    <select className="form-select" aria-label="Default select example">
    <option>Select</option>
    {Salutions.map((s, ) => { return(<option key={s}>{s}</option>)})}
    
  
</select>
      
    </div>
    
    <div className={colCls}>
    <label htmlFor="exampleInput">Country</label>



    <select className="form-select" aria-label="Default select example">
    <option >Select</option>
    {Countries.map(listofCountries)}
  
</select>
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">State</label>
    <select className="form-select" aria-label="Default select example">
    <option >Select</option>
    {List.productlist.map(listofitems)}
  
</select>
    </div>

    
    
    <div className={colCls}>
    <label htmlFor="exampleInput">City</label>
      <input type="text" className="form-control" placeholder=""/>
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">Postal Code</label>
      <input type="text" maxLength="6" className="form-control"  placeholder=" "/>
    </div>

    
    </div>
</form></div>

{/* =========================SECTION TWO=========================== */}


<div className="container form_field_container_cls ">
<form className='section_two' >
<h3 style={{paddingLeft:"15.5%"}}>Professional Experience</h3>
<p style={{paddingLeft:"15.5%"}} className="">This section is to understand your overall work experience</p>

<div className="row form_field_cls">
<div className={colCls}>
    <label htmlFor="exampleInput">Current Role in Company</label>
      {inputField}
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">Current Company</label>
      {inputField}
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">Years in current company</label>
      {inputField}
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">Current Industry</label>
      {inputField}
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">Total Years of Work Experience</label>
      {inputField}
    </div>
    <div className={colCls}>
      <input type="text" className="form-control" placeholder=" " style={{display:"none"}}/>
    </div>
</div>

</form>


</div>


{/* =======================================SECTION THREE============================================ */}


<div className="container form_field_container_cls ">
<form className='section_two' >
<h3 style={{paddingLeft:"15.5%"}}>Education</h3>
<p style={{paddingLeft:"15.5%"}} className="">This section is to understand your education background</p>

<div className="row form_field_cls">
<div className={colCls}>
    <label htmlFor="exampleInput">Highest Education Level</label>
      {inputField}
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">Institution of Highest Education Level</label>
      {inputField}
    </div>
    <div className={colCls}>
    <label htmlFor="exampleInput">Year of Graduation</label>
      {inputField}
    </div>


    <div className={colCls}>
    <label htmlFor="exampleInput">Previous Education Level</label>
    <select className="form-select" aria-label="Default select example">
    <option >Select</option>
    {inputField}
</select>
    </div>



    <div className={colCls}>
    <label htmlFor="exampleInput">Institution of Previous Education Level</label>
    <select className="form-select" aria-label="Default select example">
    <option >Select</option>
      {inputField}
      </select>
    </div>
    <div className={colCls}>
      <input type="text" className="form-control" placeholder=" " style={{display:"none"}}/>
    </div>
</div>

</form>
<div className="goto_part_2_btn">
<input type="button" className='btn btn-primary col-2' value="Go To Part 2" style={{float:"right", marginRight:"215px", backgroundColor:"#057092", border:"#057092",height:"40px", borderRadius:"0px"}}/>
</div>

</div>




         </div>

         </>
    );
};

export default OnlineApplication;