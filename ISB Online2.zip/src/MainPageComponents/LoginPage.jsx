import { Button } from "react-bootstrap";
import LandNavbar from "./LandingPage/LandNavbar";
import { MDBInput } from 'mdb-react-ui-kit';
import './LoginPage.css'
import Practice from './LandingPage/practice';



const myStyle = {
  
  fontFamily: "Roboto",
  borderRadius:"0px",
  backgroundColor:"#0686ad",
  border:"0px",
  fontStyle:"normal",
};

var validator = require("email-validator");
validator.validate("test@email.com");
const LoginPage = () => {
    return( 
    <>
    
<LandNavbar/>

<div className="bg-white border rounded-1">

<div>
<h3 className='welcm_to_isb' style={{fontSize:"2rem", top:"50px",  margin:"auto",top:"50px", position:"relative"}}> Get Started on ISBOnline</h3>
<MDBInput className="mb-4" label='Email' id='form1' type='text' style={{width:"260px"}}/>
</div>



<div className="d-grid col-7 mx-auto">
  <button className="btn mb-3 btn-primary" type="button" style={myStyle}>Continue</button>
  <strong style={{padding:"10px", margin:"auto", color:"gray"}}>
  Or
  </strong>
</div>




<div className="d-grid gap-4 col-7 mx-auto">
  <button className="btn mb-3 btn-primary" type="button" style={myStyle}> Sign up with
  <img className="socialnetwork_img" src="https://www.freepnglogos.com/uploads/google-logo-png/google-logo-png-suite-everything-you-need-know-about-google-newest-0.png"></img>
  </button>
  <button className="btn mb-3 btn-primary" type="button" style={myStyle}>Sign up with 
  <img className="socialnetwork_img" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Facebook_icon.svg/2048px-Facebook_icon.svg.png"></img>
  </button>
  <button className="btn mb-3 btn-primary" type="button" style={myStyle}>Sign up with 
  <img className="socialnetwork_img" src="https://image.similarpng.com/very-thumbnail/2020/07/Linkedin-logo-on-transparent--background-PNG.png" alt="" />
  </button>
</div>


</div>




    </>
    )
  };
  
  export default LoginPage;