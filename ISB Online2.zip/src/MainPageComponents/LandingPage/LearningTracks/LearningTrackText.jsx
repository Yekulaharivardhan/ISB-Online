import React from 'react';
import "../JoinOurCourse.css"


const LearningTrackText = () => {
    return (
        <div>
            <h3 className="join_our_crs">Available Learning Tracks </h3> 
        </div>
    );
};

export default LearningTrackText;

