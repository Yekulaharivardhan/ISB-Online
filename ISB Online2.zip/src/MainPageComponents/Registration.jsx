import React from 'react';
import LandNavbar from './LandingPage/LandNavbar';

const Registration = () => {
    return (
        <div>
         <LandNavbar/>
        </div>
    );
};

export default Registration;