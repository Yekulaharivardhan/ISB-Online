import React from 'react';
import LandNavbar from './LandingPage/LandNavbar';
import Practice from './LandingPage/practice';




var video = document.querySelector("#web_cam");

if (navigator.mediaDevices.getUserMedia) {
  navigator.mediaDevices.getUserMedia({ video: true, audio:true })
    .then(function (stream) {
      video.srcObject = stream;
      video.current.autoplay = true;
                
    })
    .catch(function (error) {
      console.log("Something went wrong!");
    });
}


const OnlineAppPartTwo = () => {
    return (
        <>
        <LandNavbar/>
      <div className="container" style={{marginTop:"130px"}}>
      
      <div className="online_applictn_form_p1">
    <h3>ISBOnline Application Form - Part 2/2</h3>
    <p>In this section, you will need to record an introduction video, and optionally submit a recording of your name to assist  others in pronoucning your name. 
If you are having any issues in recording, please visit our System Checklist and support page here. </p>
<input type="button" className='btn btn-primary col-2' value="System Checklist" style={{ backgroundColor:"#057092", border:"#057092",height:"40px", borderRadius:"0px", marginBottom:"20px"}}/>
<p className="">Once you have recorded yourself online, you can submit your application. This application is saved as a draft until you click submit. If the draft is not submitted within 30 days, it will be deleted.</p>
</div>


<div className="container form_field_container_cls">
<div className="video_cls" style={{justifyContent:"center", display:"flex"}}>
<video id='web_cam' className="col-12" height="475" controls >
<source src="" type="video/mp4"/>
  <source src="" type="video/ogg"/>
</video>
</div>





<div className="video_button_cls">
<input type="button" className='btn btn-primary ' value="Start Recording" style={{ backgroundColor:"#057092", border:"#057092",height:"40px", borderRadius:"0px", marginBottom:"20px", marginRight:"10px"}}/>
<input type="button" className='btn btn-primary' value="Play Video" style={{ backgroundColor:"#66266B", border:"#66266B",height:"40px", borderRadius:"0px", marginBottom:"20px"}}/>
</div>
</div>
</div>



</>
     
    );
};

export default OnlineAppPartTwo;