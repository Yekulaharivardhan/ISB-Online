import { Outlet, Link } from "react-router-dom";

const Layout = () => {
  return (
    <>
      
        
        
            <Link to="/">
            Home--
            </Link>
          
        
            <Link to="/ManagingStakeholders">
            ManagingStakeholders--
            </Link>
          
        
            <Link to="/LoginPage">
            LoginPage--
            </Link>
          
        
            
            <Link to="/OnlineApplication">
            OnlineApplication--
            </Link>
        

            <Link to="/OnlineAppPartTwo">
            OnlineAppPartTwo--
            </Link>
            
            <Link to="/Registration">
            Registration--
            </Link>






           
      <Outlet />
    </>
  )
};

export default Layout;