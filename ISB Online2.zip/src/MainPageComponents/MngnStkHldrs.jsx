import React from 'react';
import "../MainPageComponents/LandingPage/welcomeHome.css"
// import './LandNavbar.css'
import { Container } from 'react-bootstrap';
import WelcomeCourseimg from './LandingPage/WelcomeCourseimg';


const MngnStkHldrs = () => {
    return (
        <Container className='nav_img_cnt' style={{}} >
        <div className='nav_books' style={{}}>
        
    <div className='isb_welcome_and_img' style={{ }}>
    <WelcomeCourseimg/>
    <h1 className='welcm_to_isb'style={{ position:"absolute", zIndex:"1", margin:"5px"}}>Managing StakeHolders</h1>
    
    </div>
        </div>
        </Container>
    );
};

export default MngnStkHldrs;