import LandNavbar from "./LandingPage/LandNavbar";
import '../MainPageComponents/LandingPage/welcomeHome.css'
import WelcomeCourseimg from './LandingPage/WelcomeCourseimg';
import './ManagingStakeholders.css'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { BrowserRouter } from 'react-router-dom';
import MngnStkHldrs from './MngnStkHldrs';
import { Button } from "react-bootstrap";
import Card from 'react-bootstrap/Card';
import {LeadingPeople, LeadingPeopleone, LeadingPeopletwo, LeadingPeoplethree, LeadingPeoplefour }from './LeadingPeople';


let F={fontWeight:"bold"}


const ManagingStakeholders = () => {
    return(
    <>
    
    <LandNavbar/>
    <MngnStkHldrs/>
    
   

<Container>

<div className="grid-container">
<div className="grid-item item1">

<ul className="Mngn_stckholdrs_contnt"><p/>
    <li>What is Managing Stakeholders</li><p/>
    <li>Who is this course for?</li><p/>
    <li>What will i get on completion</li><p/>
    <li>Course Outlet</li><p/>
</ul>

</div>

<div className="grid-item item2">
<h3> What is Managing Stakeholders?  </h3>
<p>Negotiation strategies at workplace plays a critical role in managing stakeholders and enabling better coordination on work activities. In this course, Prof. Nikhil Madan, will help you understand what a negotiation is and why we negotiate in required situations. This course covers two party distributive negotiations and integrative negotiations, dispute resolution, dealing with lying in negotiations and building trust in negotiations.</p></div>

<div className=" grid-item item3">
<h4 style={{fontWeight:"bold"}}>Managing <br/>Stakeholders</h4>
<p>This course is available for all professionals, on a cohort basis, with 40 Hours of Interactive Course Material, over 6 weeks of material and assessments.</p>

<div className="durtn" style={{wordSpacing:"50px"}}><strong>5Weeks 40Hrs</strong></div>
<br/><p>The course is run every month, so you can join the upoming cohort</p>
<div><p>Cost <strong>-30,000 + Taxes</strong></p></div>
<br/>
<article>Next Batch - 4 Oct 2022</article>

<br/>
<Button variant = "btn btn-outline-dark col-12" style={{backgroundColor:"#057092", border:"white",color:"white", borderRadius:"0px"}}>Apply</Button><br/><br/>
<h6 >Upcoming Batch</h6>

<ul>
    <p>31 July 2022</p>
    <p>02 August 2022</p>
    <p>30 July 2022</p>
    <p>02 August 2022</p>
    <p>30 July 2022</p>
</ul>
    
</div>
<div>



</div>

<div className=" grid-item item4">


    <h3>Who is this course for?</h3>
    <p>Leading People and Change is a course designed to develop and expand the essential knowledge, skills, and mindset required to lead people and teams effectively. The course will help you to learn skills required for stakeholder engagement, and techniques to drive high-performing teams and deal with change. You will be able to manage conflict and change, delegate and collaborate effectively, and empathize and influence others.</p>
</div>

<div className=" grid-item item5">
<img className="msh_prof_img" src="./images/profimg.jpg" alt="" />
<div className="prof_txt">
<h4>Prof. Nikhil Madan</h4>
<p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vel, odit? </p>
<strong><Card.Link href="#" style={{textDecoration:"none"}}>Read Full Profile</Card.Link> </strong>
</div>
</div>
<div className=" grid-item item6">
<h3>What Will I get on Completion?</h3>
<img className="WWIcompletion" src="./images/WWIcompletion.jpg" alt="" />
<div className="on_completion_para">
<p>On successful completion, you will be mailed a physical certificate to your registered address.<br/>
 
 Additionally, you will receive a digital certificate from ISBOnline. This digital certificate can be embedded in your CV or added on LinkedIn for online verification.
 
 You will also be added to the ISB Alumni Online Network where you can connect with your peers who have also completed ISB.Online course</p>

</div></div>

<div className=" grid-item item8">



<div>
<h5>Leading People and Change</h5>
<p>10 Modules, 40 Hours of Content</p>
<LeadingPeople/>
<LeadingPeopleone/>
<LeadingPeopletwo/>
<LeadingPeoplethree/>
<LeadingPeoplefour/>


</div>

</div>
</div>
</Container>
    </>)
  };
  
  export default ManagingStakeholders;