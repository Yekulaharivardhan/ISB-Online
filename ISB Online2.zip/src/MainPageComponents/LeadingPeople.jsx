import React from 'react';
import useCollapse from 'react-collapsed';
import './LeadingPeople.css'
import { useState } from 'react';



const lorem50= ("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione consequatur a non amet eaque quis ut commodi exercitationem aperiam, molestias quia eum doloribus, similique tenetur culpa nostrum accusamus at dolor alias corrupti laudantium tempora aut? Quod natus cupiditate molestiae minus iste dicta iure, assumenda, dignissimos, libero quasi incidunt officiis sint.")
const C= (<i className="fa-solid fa-chevron-up"></i>)
const E = (<i className="fa-solid fa-chevron-down"></i>)

export function LeadingPeople() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="collapsible">
        <div className="header" {...getToggleProps()}>
        
            {isExpanded ? C : E }
            <p><strong> Module 0 - Welcome & Introduction</strong></p>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            {lorem50}
            
            
            </div>
        </div>
    </div>

</>



    );
}


export function LeadingPeopleone() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="collapsible">
        <div className="header" {...getToggleProps()}>
       
        {isExpanded ? C : E }
            <p><strong> Module 1 - Interpersonal Relationships</strong></p>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            {lorem50}
            </div>
        </div>
    </div>

</>



    );
}

export function LeadingPeopletwo() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="collapsible">
        <div className="header" {...getToggleProps()}>
       
        {isExpanded ? C : E }
            <p><strong> Module 2 - Influence Without Authority</strong></p>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            {lorem50}
                
            </div>
        </div>
    </div>

</>



    );
}

export function LeadingPeoplethree() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="collapsible">
        <div className="header" {...getToggleProps()}>
        
        {isExpanded ? C : E }
            <p> <strong>Module 3 - Conflict Management</strong></p>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            {lorem50}
                
            </div>
        </div>
    </div>

</>



    );
}
export function LeadingPeoplefour() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="collapsible">
        <div className="header" {...getToggleProps()}>

        



        {isExpanded ? C : E }
            <p> <strong>Module 4 - Fostering Psychological Safety</strong></p>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            {lorem50}
                
            </div>
        </div>
    </div>

</>



    );
}
