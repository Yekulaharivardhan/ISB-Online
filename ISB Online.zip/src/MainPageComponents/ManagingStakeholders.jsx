import LandNavbar from "./LandingPage/LandNavbar";
import '../MainPageComponents/LandingPage/welcomeHome.css'
import WelcomeCourseimg from './LandingPage/WelcomeCourseimg';
import './ManagingStakeholders.css'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { BrowserRouter } from 'react-router-dom';
import MngnStkHldrs from './MngnStkHldrs';


const ManagingStakeholders = () => {
    return(
    <>
    
    <LandNavbar/>
    <MngnStkHldrs/>
    
    {/* <div className="container" >
   
<div class="row">
  <div class="col-md-8">
  <div class="pb-3 item1"> .col-md-8 </div> 
  <div class="pb-3 item1"> .col-md-8 </div>
    
    <div class="row">
      <div class="col-md-6 item2">.col-md-6</div>
      <div class="col-md-6 item2">.col-md-6</div>
    </div>
  </div>
  <div class="col-md-2 item4">.col-md-4</div>
  
</div>
</div> */}

    {/* <div className="container my_container">
      <Row>
        <Col className="item-1 col-md-2" style={{height:"250px", backgroundColor:"red", border:"2px solid white"}}>1 of 6</Col>
        <Col className="item-2 col-md-6 m-2" style={{height:"150px", backgroundColor:"blue", border:"2px solid white"}}>2 of 6</Col>
        <Col className="item-3 col-md-2" style={{height:"350px", backgroundColor:"green", border:"2px solid white"}}>3 of 6</Col>
        <Col className="item-3 col-md-2"  style={{height:"200px", backgroundColor:"green", border:"2px solid white"}}>4 of 6</Col>
        <Col className="item-2 col-md-6 m-2 " style={{height:"150px", backgroundColor:"blue", border:"2px solid white"}}>5 of 6</Col>
        <Col className="item-3 col-sm-2"  style={{height:"200px", backgroundColor:"green", border:"2px solid white"}}>6 of 6</Col>
      </Row> */}
      {/* <Row>
        <Col className="item-3">1 of 3</Col>
        <Col className="item-4">2 of 3</Col>
        <Col className="item-5">3 of 3</Col>
      </Row> */}
    



{/* 
<div className="grid-container container container_page_two">
            <div className="row">
                <div className="col-md-3 mygrid grid-item-1">1</div>
                <div className="col-md-6 mygrid grid-item-2">2</div>
                <div className="col-md-3 mygrid grid-item-3">3</div>
                <div className="col-md-3 mygrid grid-item-4">4</div>
                <div className="col-md-6 mygrid grid-item-5">5</div>
                </div></div>



                <div className="grid-container container container_page_two">              
            <div className="row">
           
            
            </div></div>

            <div className="container container_page_two">              
            <div className="row">
            <div className="col-md-3 mygrid grid-item-6">6</div>
</div></div> */}





<Container>

<div className="grid-container">
<div className="grid-item item1">

<ul className="Mngn_stckholdrs_contnt">
    <li>What is Managing Stakeholders</li><p/>
    <li>Who is this course for?</li><p/>
    <li>What will i get on completion</li><p/>
    <li>Course Outlet</li><p/>
</ul>

</div>

<div className="grid-item item2">
<h3> What is Managing Stakeholders?  </h3>
<p>Negotiation strategies at workplace plays a critical role in managing stakeholders and enabling better coordination on work activities. In this course, Prof. Nikhil Madan, will help you understand what a negotiation is and why we negotiate in required situations. This course covers two party distributive negotiations and integrative negotiations, dispute resolution, dealing with lying in negotiations and building trust in negotiations.</p></div>

<div className=" grid-item item3">
<h3>Managing Stakeholders</h3>
<p>This course is available for all professionals, on a cohort basis, with 40 Hours of Interactive Course Material, over 6 weeks of material and assessments.</p>
</div>

<div className=" grid-item item4">


    <h3>Who is this course for?</h3>
    <p>Leading People and Change is a course designed to develop and expand the essential knowledge, skills, and mindset required to lead people and teams effectively. The course will help you to learn skills required for stakeholder engagement, and techniques to drive high-performing teams and deal with change. You will be able to manage conflict and change, delegate and collaborate effectively, and empathize and influence others.</p>
</div>

<div className=" grid-item item5">
<img className="msh_prof_img" src="./images/profimg.jpg" alt="" />
<div className="prof_txt">
<h5>Prof. Nikhil Madan</h5>
<p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vel, odit? </p>
</div>
</div>
<div className=" grid-item item6">item-6</div>
<div className=" grid-item item7">item-7</div>
<div className=" grid-item item8">item-8</div>
</div>
</Container>
    </>)
  };
  
  export default ManagingStakeholders;