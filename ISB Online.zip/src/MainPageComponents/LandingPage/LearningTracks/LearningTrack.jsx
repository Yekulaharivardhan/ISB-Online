
import "./LearningTrack.css";
import React from 'react';

const LearningTrack = () => {
    return (
        <div>

<div className='flex_main_container
'>
<div className="lrning_trck_main lrning_trck_main-1">
 <img className='lrning_card_img' src="./images/Management.jpg" alt="" />
 <h4>Management</h4>
</div>

<div className="lrning_trck_main lrning_trck_main-2">
 <img className='lrning_card_img' src="./images/Business.jpg" alt="" />
 <h4>Business</h4>
</div>

<div className="lrning_trck_main lrning_trck_main-3">
 <img className='lrning_card_img' src="./images/Leadership.jpg" alt="" />
 <h4>Leadership</h4>
</div>

<div className="lrning_trck_main lrning_trck_main-4">
 <img className='lrning_card_img' src="./images/Marketing.jpg" alt="" />
 <h4>Marketing</h4>
</div>
</div>



{/* 
<div className="Lrning_trcks_main">
    
    <Card style={{ marginBottom:"20px" }}>
    <div className="flexbox-item flexbox-item-1">
      <Card.Img className='frame_two_crd_img_sml' variant="top" src="./images/Management.jpg" style={{}}/>
     
      <Card.Body className='card_body'>
        <Card.Title>Management</Card.Title>
       
      </Card.Body>
      
      </div>
    </Card>


<Card style={{ marginBottom:"20px"
 
  }}>
  <div className="flexbox-item flexbox-item-2">
      <Card.Img className='frame_two_crd_img_sml' variant="top" src="./images/Business.jpg" style={{}}/>
      <Card.Body>
        <Card.Title>Business</Card.Title>
        
      </Card.Body></div>
    </Card>


<Card style={{ marginBottom:"20px"
  
  }}>
  <div className="flexbox-item flexbox-item-3">
      <Card.Img className='frame_two_crd_img_sml' variant="top" src="./images/LeaderShip.jpg" style={{}}/>
      <Card.Body>
        <Card.Title>LeaderShip</Card.Title>
        
      </Card.Body></div>
    </Card>
    
    <Card style={{ marginBottom:"20px"
  
}}>
<div className="flexbox-item flexbox-item-4">
    <Card.Img className='frame_two_crd_img_sml' variant="top" src="./images/Marketing.jpg" style={{}}/>
    <Card.Body>
      <Card.Title>Marketing</Card.Title>
      
    </Card.Body></div>
  </Card>
    
    
    
    </div>
     */}


        </div>
    );
};

export default LearningTrack;



  