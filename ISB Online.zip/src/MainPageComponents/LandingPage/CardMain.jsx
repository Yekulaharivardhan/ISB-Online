import React from 'react';
import CoursesCards from './CoursesCards';
import data from './data';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const CardMain = () => {
    return (
      
       <>

<div className="container-sm ">
      <div className="row">
              {data.productData.map((props) => {
                return (
                  <CoursesCards
                    key={props.id}
                    img={props.img}
                    title={props.title}
                    desc={props.desc}
                    durtnweeks={props.durtnweeks}
                    durtnhrsperweek={props.durtnhrsperweek}
                    price={props.price}
                    // item={props}
                    
                  />
                                    
                );
              })}  


</div></div>

              </> 
              
  
      );
};

export default CardMain;