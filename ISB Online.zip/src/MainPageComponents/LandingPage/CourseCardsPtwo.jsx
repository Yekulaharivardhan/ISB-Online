import Card from 'react-bootstrap/Card';
import "./CourseCardsPtwo.css";
import { Container } from 'react-bootstrap';

function CourseCardsPtwo() {
  return (
    <>
    <div className="flexbox-container">
    {/* <Container className='cards_container' style={{width:"1440px"}}>
    <div className='cards_frame_two' style={{}}>
    <div className='col-15 mb-4'>
    <div className='row' >   */}
    {/* <h2>What Sets ISB Online Apart</h2> */}
    <Card style={{ marginBottom:"20px"
      // width: '20.5rem', marginRight:"40px",marginBottom:"40px", 
    }}>
    <div className="flexbox-item">
      <Card.Img className='frame_two_crd_img' variant="top" src="./images/engaging.jpg" style={{width:"100px"}}/>
     
      <Card.Body className='card_body_div'>
        <Card.Title>Engaging</Card.Title>
        <Card.Text>
        ISBOnline is designed with the latest insights into digital learning, and applies specific lesson features like short bursts of content and thought provoking questions
        </Card.Text>
      </Card.Body>
      
      </div>
    </Card>


<Card style={{ marginBottom:"20px"
  // width: '20.5rem',marginRight:"40px",marginBottom:"40px" 
  }}>
  <div className="flexbox-item">
      <Card.Img className='frame_two_crd_img' variant="top" src="./images/social.jpg" style={{width:"100px"}}/>
      <Card.Body>
        <Card.Title>Social</Card.Title>
        <Card.Text style={{flexShrink:"0"}}>
        ISBOnline is designed with the latest insights into digital learning, and applies specific lesson features like short bursts of content and thought provoking questions
        </Card.Text>
      </Card.Body></div>
    </Card>


<Card style={{ marginBottom:"20px"
  // width: '20.5rem',marginRight:"40px",marginBottom:"40px" 
  }}>
  <div className="flexbox-item">
      <Card.Img className='frame_two_crd_img' variant="top" src="./images/immersive.jpg" style={{width:"100px"}}/>
      <Card.Body>
        <Card.Title>Immersive</Card.Title>
        <Card.Text className='card_desc' style={{}}>
        ISBOnline is designed with the latest insights into digital learning, and applies specific lesson features like short bursts of content and thought provoking questions
        </Card.Text>
      </Card.Body></div>
    </Card></div>
    {/* </div></div></div>
    </Container> */}
    
    </>
  );
}

export default CourseCardsPtwo;