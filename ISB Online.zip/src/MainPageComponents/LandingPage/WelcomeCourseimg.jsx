import React from 'react';
import "./welcomeHome.css"
// import './LandNavbar.css'
import { Container } from 'react-bootstrap';

const WelcomeCourseimg = () => {
    return (
        <Container className='nav_img_cnt' style={{}} >
        <div className='nav_books' style={{}}>
        
    <div className='isb_welcome_and_img' style={{ }}>
    <img className='Welcome_books_img' src="./images/bookscrop.jpg" alt="" style={{height:"100px", width:"100%",marginTop:"100px",}}/>
    
    </div>
        </div>
        </Container>
    );
};

export default WelcomeCourseimg;