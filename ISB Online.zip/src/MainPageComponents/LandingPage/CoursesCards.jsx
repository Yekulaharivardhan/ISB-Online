import React from 'react';
import {Container} from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
// import Row from 'react-bootstrap/Row';
// import Col from 'react-bootstrap/Col';
import './CourseCards.css'
import { Link } from 'react-router-dom';


function CoursesCards(props) {

  
    return (
        
<>


<Container className='cards_container' style={{width:"350px"}}>
    <div className='cards_frame_two' style={{marginBottom:"50px"}}>
    <div className='col-15  mb-4'>
  <div className='' style={{display:"flex",flexDirection:"row"}}> 
 

    <div className="card" style={{ width: '20.5rem', maxHeight:"26rem" }}>
      <Card.Img variant="top" src={props.img} style={{height:"138px"}}/>
      <Card.Body>
        <Card.Title className='cards_title'>{props.title}</Card.Title>
        <Card.Text className='cards_desc' style={{fontSize:"0.8rem"}}>{props.desc}<Card.Link href="#" style={{textDecoration:"none"}}>Learn More...</Card.Link> </Card.Text>
        <div className='col-15 ' style={{}}>
        <Card.Text className='durtn_weeks'>{props.durtnweeks}</Card.Text>
        <Button type="button" className="btn btn-primary" style={{float:"right"}}>Get Started</Button>
        <Card.Text className='durtn_weeks'>{props.durtnhrsperweek} </Card.Text>
        <span className='card_pricing'>₹{props.price} + Taxes</span>
        
        </div>
        </Card.Body>
</div></div></div></div>
</Container>




</>
        
);
}

export default CoursesCards;