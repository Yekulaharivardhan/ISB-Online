import React from 'react';

const Registration = () => {
    return (
        <div>
          <h1> This is Registration Page </h1>
        </div>
    );
};

export default Registration;