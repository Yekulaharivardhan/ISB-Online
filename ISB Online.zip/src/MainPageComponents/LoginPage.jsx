import { Button } from "react-bootstrap";
import LandNavbar from "./LandingPage/LandNavbar";
import { MDBInput } from 'mdb-react-ui-kit';
import './LoginPage.css'





var validator = require("email-validator");
validator.validate("test@email.com");
const LoginPage = () => {
    return( 
    <>
    
<LandNavbar/>

<div className="bg-white border rounded-5">



<MDBInput className="mb-4" label='Email' id='form1' type='text' style={{width:"260px"}}/>




<div class="d-grid col-7 mx-auto">
  <button class="btn mb-5 btn-primary" type="button">Continue</button>
</div>

<span>Or</span>


<div class="d-grid gap-2 col-7 mx-auto">
  <button class="btn btn-primary" type="button">Sign up with Google</button>
  <button class="btn btn-info" type="button">Sign up with Facebook</button>
  <button class="btn btn-primary" type="button">Sign up with Linkedin</button>
</div>


</div>




    </>
    )
  };
  
  export default LoginPage;