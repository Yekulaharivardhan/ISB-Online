import React from 'react';
import {Container} from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
// import Row from 'react-bootstrap/Row';
// import Col from 'react-bootstrap/Col';
import './CourseCards.css'
import { Link } from 'react-router-dom';
import BooksImg from './../pages/FinalExamPages/BooksImg';


function CoursesCards(props) {

  
    return (
        
<>


<Container className='cards_container' style={{width:"350px", }} 
>
    {/* <div className='cards_frame_two' style={{marginBottom:"0px"}}> */}
    {/* <div className=' '> */}
  {/* <div className='indiv_card_container' style={{display:"flex",flexDirection:"row"}}>  */}
 

    {/* <div className="card" style={{ width: '20.5rem', maxHeight:"26rem" }}> */}
      <Card.Img variant="top col-12 mb-2 " src={props.img} style={{height:"140px",borderRadius:"10px 10px 0 0"}}/>
      <Card.Body className='p-3'>
        <Card.Title className='cards_title'>{props.title}</Card.Title>
        <Card.Text className='cards_desc' style={{fontSize:"0.8rem",height:"145px"}}>{props.desc}<Card.Link href="#" style={{textDecoration:"none"}}>Learn More...</Card.Link> </Card.Text>
        <div className='col-15 ' style={{}}>
        <Card.Text className='durtn_weeks'>{props.durtnweeks}</Card.Text>
        <div className="navigate">
            <Link to="/EffectiveNego">
        <Button type="button" className="btn btn" style={{float:"right", backgroundColor:"#057092", borderRadius:"0", border:"0"}}>Get Started</Button>
</Link>
          </div>
        <Card.Text className='durtn_weeks'>{props.durtnhrsperweek} </Card.Text>
        <span className='card_pricing'>₹{props.price} + Taxes</span>
        
        </div>
        </Card.Body>


</Container>



</>
        
);
}

export default CoursesCards;