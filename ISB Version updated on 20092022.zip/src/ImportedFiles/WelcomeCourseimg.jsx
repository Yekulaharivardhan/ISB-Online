import React from 'react';
// import './LandNavbar.css'


const WelcomeCourseimg = () => {
    return (
        <>


<div className='isb_welcome_and_imgs' >
        
            
        {/* <div className='nav_books' style={{display:"flex"}}> */}
{/* <div className='isb_welcome_and_img' style={{}}> */}
<img className='Welcome_books_img' src="./images/TopBanner.png" alt="" style={{height:"90px", width:"77rem",display:"flex"}}/>

</div>

 
 {/* </div>       */}
         
        </>
    );
};

export default WelcomeCourseimg;