import "./JoinOurCourse.css"

const JoinOurCourse = () => {
    return (

<div>
<h3 className="join_our_crs">Join our Professional Courses</h3>
</div>


      );
}
 
export default JoinOurCourse;