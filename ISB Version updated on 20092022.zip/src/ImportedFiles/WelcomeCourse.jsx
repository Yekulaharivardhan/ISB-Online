import React from 'react';
import WelcomeCourseimg from './WelcomeCourseimg';


const WelcomeCourse = () => {
    return (
   
        
        
        
        
    <div className='isb_welcome_and_img' style={{ }}>
    <WelcomeCourseimg/>
    <h1 className='welcm_to_isb'style={{ position:"absolute", zIndex:"1"}}>Welcome to ISB Online</h1>
    
    </div>
        
    );
};

export default WelcomeCourse;