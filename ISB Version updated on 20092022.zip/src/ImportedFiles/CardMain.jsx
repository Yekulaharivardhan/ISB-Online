import React from 'react';
import CoursesCards from './CoursesCards';
import data from './data';
import CourseCardsPtwo from './CourseCardsPtwo';
import LearningTrack from './LearningTrack';
import WelcomeCourse from './WelcomeCourse';


const CardMain = () => {
    return (
      
       <>

<div className="container-sm " style={{ marginTop:"220px"}}>
      <div className="row" style={{padding:"0"}}>
              {data.productData.map((props) => {
                return (
                  <CoursesCards
                    key={props.id}
                    img={props.img}
                    title={props.title}
                    desc={props.desc}
                    durtnweeks={props.durtnweeks}
                    durtnhrsperweek={props.durtnhrsperweek}
                    price={props.price}
                    item={props} 
                    
                  />
                                    
                );
              })}  


</div></div>
<CourseCardsPtwo/>
<LearningTrack/>
<WelcomeCourse/>
              </> 
              
  
      );
};

export default CardMain;