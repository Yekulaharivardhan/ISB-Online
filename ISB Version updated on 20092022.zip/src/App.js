// import React, { useState } from "react";
import React from "react";
import "./App.css";
import APage from "./pages/APage";
import {  Switch } from "react-router-dom";
import {  Routes, Route, BrowserRouter } from "react-router-dom";
import CPage from "./pages/CPage";
import { TransitionGroup, CSSTransition } from "react-transition-group";
import { withRouter as Router } from "react-router-dom";
import "./pageTransitions/slideTransition.css";
import BPage from './pages/BPage';
import DPage from './pages/DPage';
import EPage from './pages/EPage';
import FPage from './pages/FPage';
import GPage from './pages/GPage';
import HPage from './pages/HPage';
import {AAStartExam} from '././pages/FinalExamPages/AAStartExam';
import AExam from '././pages/FinalExamPages/AExam';
import BExam from '././pages/FinalExamPages/BExam';
import CExam from '././pages/FinalExamPages/CExam';
import DExam from '././pages/FinalExamPages/DExam';
import EExam from '././pages/FinalExamPages/EExam';
import FExam from '././pages/FinalExamPages/FExam';
import GExam from '././pages/FinalExamPages/GExam';
import HExam from '././pages/FinalExamPages/HExam';
import IExam from '././pages/FinalExamPages/IExam';
import JExam from '././pages/FinalExamPages/JExam';
import KExam from '././pages/FinalExamPages/KExam';
import TestCompleted from '././pages/FinalExamPages/TestCompleted';
import CardMain from './ImportedFiles/CardMain';
// import ENegoPersu from './pages/ENegoFiles/ENegoPersu';
// import ManagingStakeholders from './ImportedFiles/ManagingStakeholders';
import EffectiveNego from './pages/LearnerFlowComponents/EffectiveNego';
// import { useLocation  } from 'react-router-dom';
import { Component } from 'react';




class App extends Component {
constructor(props) {
  super(props);
  this.state = {
    previousPath: this.getPathDepth(this.props.location)
    
  };
  
  
}

getDerivedStateFromProp() {                                              //componentWillReceiveProps to getDerivedStateFromProp
  this.setState({ previousPath: this.getPathDepth(this.props.location) });
  
}

getPathDepth(location) {
  let pathArray = location.pathname.split("/");
  pathArray = pathArray.filter(n => n !== "");
  return pathArray.length;
}

  render() {
    const { location } = this.props;

    const currentKey = location.pathname.split("/")[1] || "/";
    const timeout = { enter: 900, exit: 450 };

    return (
      <TransitionGroup component="div" className="App">
        <CSSTransition
          key={currentKey}
          timeout={timeout}
          classNames="pageSlideAnimation"
          mountOnEnter={true}
          unmountOnExit={false}
        >
<div
  className={
    this.getPathDepth(location) - this.state.previousPath >= 0
      ? "left"
      : "right"
  }
>

<BrowserRouter>


</BrowserRouter>

  <Switch location ={location}>
 
  <Route path="/" exact component={CardMain} />
    <Route path="/APage" index component={APage} />
    <Route path="/BPage"  component={BPage} />
    <Route path="/CPage"  component={CPage} />
    <Route path="/DPage"  component={DPage} />
    {/* <Route path="/NavBar"  component={NavBar} /> */}
     <Route path="/EPage"  component={EPage} />
    <Route path="/FPage"  component={FPage} />
    <Route path="/GPage"  component={GPage} />
    <Route path="/HPage"  component={HPage} />
    <Route path="/AAStartExam"  component={AAStartExam} />
    <Route path="/AExam"  component={AExam} />
    <Route path="/BExam"  component={BExam} />
    <Route path="/CExam"  component={CExam} />
    <Route path="/DExam"  component={DExam} />
    <Route path="/EExam"  component={EExam} />
    <Route path="/FExam"  component={FExam} />
    <Route path="/GExam"  component={GExam} />
    <Route path="/HExam"  component={HExam} />
    <Route path="/IExam"  component={IExam} />
    <Route path="/JExam"  component={JExam} />
    <Route path="/KExam"  component={KExam} />
    <Route path="/TestCompleted"  component={TestCompleted} />
    <Route path="/EffectiveNego"  component={EffectiveNego} /> 
    {/* <Route path="/ManagingStakeholders"  component={ManagingStakeholders} /> */}

    
    
  </Switch>
</div>
        </CSSTransition>
      </TransitionGroup>
    );
  }
}

export default Router(App);
