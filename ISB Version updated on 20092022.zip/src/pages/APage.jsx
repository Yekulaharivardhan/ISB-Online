import React from "react";
import "./homePageStyle.css";

import { Link } from "react-router-dom";

export default class APage extends React.Component {
  render() {
    return (


      <div className="page-container page">
      <div className="about-page inner-container">
        <div className="container">
        <div className="mycontainer_cls">
        <h3 className="distrbtv_nego_titles" >Learning Objectives 1</h3>
        <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
         <ul ><p><li>
        Differentiate between Intuitive Thinking and Reason Based Thinking</li>
        <li>
Identify the characteristics of Intuitive Thinking and Reason Based Thinking</li>
<li>Explain Naïve Realism</li>
<li>Identify situations that involve illusion of objectivity</li>
</p> </ul>
        <div className="navigate">
            <Link to="/BPage">
              <button className="submit_button">Next <img src="./images/downarrow.png" alt="" />  </button>
            </Link>
          </div>

        </div>
        
      </div>
    </div>


      

         
         
         
        
      
    );
  }
}
