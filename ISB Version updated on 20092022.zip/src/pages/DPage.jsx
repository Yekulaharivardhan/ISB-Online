import React from "react";
import { Link } from "react-router-dom";
import "./homePageStyle.css";

export default class AboutPageTwo extends React.Component {
  render() {
    return (<>
      
      <div className="page-container page">
      <div className="about-page inner-container">
        <div className="containers" style={{width:"850px",margin:"auto", padding:"20px",marginTop:"80px",}} >
        <div className="mycontainer_cls">
          
        
        
        </div>
        <h3 style={{textAlign:"end"}} className="distrbtv_nego_titles" >Video 2: The Unsolvable Problem</h3>
        <img src="./images/IntroToCollabVid.png" alt="" style={{height:"350px",marginBottom:"10px"}}/>
          
          <div className="navigation">
            <Link to="/EPage">
            <button className="next_button" style={{margin:"auto"}}>Next <img src="./images/downarrow.png" alt="" />  </button>
            </Link>
          </div>
        </div> </div></div>
      </>
    );
  }
}
