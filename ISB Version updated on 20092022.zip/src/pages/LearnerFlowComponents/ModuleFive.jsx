import React from 'react';
import useCollapse from 'react-collapsed';
import ModFiveData from './ModFiveData';
import { Link } from 'react-router-dom';


const Moduletxt = ["Team Negotiations","Information Pooling in Teams","Conclusion to Team Negotiations","Quiz","Reading Materials"]

const C= (<i className="fa-solid fa-chevron-up"></i>)
const E = (<i className="fa-solid fa-chevron-down"></i>)




export function ModuleFive() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="Module0 h3"><img src="./images/FullCircle.png" alt="" style={{display:"flex",margin:"10px 0 -47px 0px",}}/>
        <div className="header" {...getToggleProps()}>
        
            {isExpanded ? C : E }
            <h3> Module 5: Team Negotiations</h3>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            <ul>
{ModFiveData.ModFiveData.map((m ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">

<Link to='/APage' style={{textDecoreation:"none"}}>
<h5 key={m.id}>
    <div className="im col-7">
    {m.title}
    </div>
    <div className="im col-1 dimond_img" style={{}}>
    <img src={m.img} alt="" style={{}} /> 
    </div>
    <p className="im col-2 score_cls" style={{}}>
    {m.score}</p>
    <div className="im col-2 lession_status" style={{}}>
    <span style={{}}> {m.lessionstatus}</span>
    </div>

     </h5></Link>
    </div></div> 
    </>
    )})}

</ul>
   
            </div>
        </div>
    </div>

</>

    );
};

