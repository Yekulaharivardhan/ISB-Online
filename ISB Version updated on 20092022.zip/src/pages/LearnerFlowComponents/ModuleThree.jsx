import React from 'react';
import useCollapse from 'react-collapsed';
import ModThreeData from './ModThreeData';
import { Link } from 'react-router-dom';

const Moduletxt = ["Introduction to Integrative Negotiations","General Concepts of Integrative Negotiations","Strategies of Integrative Negotiations","Value Creation Strategies","Exercise on ISB.Town - Scoring Table Simulation","Conclusion to Integrative Negotiations","Quiz","Reading Materials"]

const C= (<i className="fa-solid fa-chevron-up"></i>)
const E = (<i className="fa-solid fa-chevron-down"></i>)




export function ModuleThree() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="Module0 h3"><img src="./images/FullCircle.png" alt="" style={{display:"flex",margin:"10px 0 -47px 0px",}}/>
        <div className="header" {...getToggleProps()}>
        
            {isExpanded ? C : E }
            <h3> Module 3: Integrative Negotiations</h3>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            <ul>
{ModThreeData.ModThreeData.map((three ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">
<Link to='/APage' style={{textDecoration:"none"}}>
<h5 key={three.id}>
    <div className="im col-7">
    {three.title}
    </div>
    <div className="im col-1 dimond_img" style={{}}>
    <img src={three.img} alt="" style={{}} /> 
    </div>
    <p className="im col-2 score_cls" style={{}}>
    {three.score}</p>
    <div className="im col-2 lession_status" style={{}}>
    <span style={{}}> {three.lessionstatus}</span>
    </div>

     </h5></Link>
    </div></div> 
    </>
    )})}

</ul>
   
            </div>
        </div>
    </div>

</>

    );
};

