import React from "react";
import "../homePageStyle.css";

import { Link } from "react-router-dom";
import BooksImg from './BooksImg';


export class AAStartExam extends React.Component {
  render() {
    return (
<>

    

       


      <div className="page-container page"> 
      <div className="about-page inner-container">
      <BooksImg/>
        <div className="container">
        <div className="mycontainer_cls">
        
        
        <h3 className="distrbtv_nego_titles">About the Exam</h3>
        <p> In this test, there are 10 Multiple Choice Questions, followed by a final question where you will need to submit a 500 word response to the question. All progress is auto saved.       </p>
        </div>
        
        
        <p className="abt_exm_txt">Click Start to start the Exam.</p>
        <div className="navigate">
            <Link to="/AExam">
              <button className="start_exam_button">Start Exam </button>
            </Link>
          </div>

        </div>
       
      </div>
    </div>
    
        
    </>
    );
  }
}



