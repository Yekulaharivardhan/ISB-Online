import React from 'react';
import { Link } from 'react-router-dom';


const TestCompleted = () => {
    return (
        <div>
        <div className="test_submitted_container">
          <div className="test_completed_page">

          <div className="image_contnr">
          <img className='img_container' src= "./images/rightmark.png" alt="" />
          <img className='tick_img' src= "./images/tickmark.png" alt="" />
</div>

            <h3 className='test_submitd_titl'>Test Submitted</h3>
            <p>Your test responses have now been submitted. Your responses will be evaluated and you will receive your resutls within 48 hours. 
You may now continue to the dashboard</p>

<Link to="/" style={{textDecoration:"none"}}>            
            
            <button className="cont_to_dashbd_btn"><p>Continue to Dashboard</p> </button>
            
            </Link>

</div>

          </div>


        </div>
    );
};

export default TestCompleted;