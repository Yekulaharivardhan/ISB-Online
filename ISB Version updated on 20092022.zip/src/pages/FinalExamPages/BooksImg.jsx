import React from 'react';

const BooksImg = () => {
    return (
        <>
        
        
            
           <div className='nav_books_img_final_exam' style={{display:"flex",marginTop:"80px",}}>
{/* <div className='isb_welcome_and_img' style={{}}> */}
<img className='Welcome_books_imgs' src="./images/TopBanner.png" alt="" style={{height:"90px", width:"100%",}}/>
</div>
   
    <h1 className='welcm_to_isb'style={{ zIndex:"1",marginTop:"-80px"}}>Final Exam</h1>
  
        </>
    );
};

export default BooksImg;

