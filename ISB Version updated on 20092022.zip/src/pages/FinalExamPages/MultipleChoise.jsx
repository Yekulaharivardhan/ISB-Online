import React from 'react';

const MultipleChoise = () => {
    return (
        <>
<div className="select_options" style={{}}>
<div className="form-check final_exam_form_chck">
<input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
<label className="form-check-label" htmlFor="flexRadioDefault1">
<p className='final_exam_qustns'> 1.	Individual efforts of Survival, Managerial, and Technical</p>
</label>
</div>


<div className="form-check final_exam_form_chck">
<input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" />
<label className="form-check-label" htmlFor="flexRadioDefault2">
<p className='final_exam_qustns'> 2.	Hierarchal efforts on Survival, Managerial, and Technical</p>
</label>
</div>


<div className="form-check final_exam_form_chck">
<input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
<label className="form-check-label" htmlFor="flexRadioDefault1">
<p className='final_exam_qustns'> 3.	Individual and Interlinking efforts on Survival, Managerial, and Technical.  </p>
</label>
</div>


<div className="form-check final_exam_form_chck">
<input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
<label className="form-check-label" htmlFor="flexRadioDefault1">
<p className='final_exam_qustns'> 4.	Interlinking efforts on Survival, Managerial, and Technical</p>
</label>
</div>
</div>

        </>
    );
};

export default MultipleChoise;

