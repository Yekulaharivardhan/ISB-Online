import React from 'react';
import { Link } from 'react-router-dom';
import BooksImg from './BooksImg';
import "../homePageStyle.css";



 const KExam = () => {
    return (
        <>
      
      {/* <BooksImg/> */}
          
      <div className="page-container page" > 
      <div className="about-page inner-container">

        <div className="container" >
        <div className="mycontainer_cls">
        

        <h3 className='final_exam_txt'>Final Question</h3>
        <p className='final_exam_qustn'> What are your key learning from this programme?</p>
        <p className='final_exam_qustn'> Please write a minimum note of 500 words for this question. This will be evaluated and your course completion will be determined based on this. A plagiarism cherk will also be performed. </p>
        </div>
              <div className="final_exam_qustn_note">
                <textarea name="" id="submit_text_area_note" cols="30" rows="10" placeholder='Text'></textarea>
              </div>
           <p className='auto_save_txt'>   Autosaved 15 seconds ago</p>
        
       
        </div> 
        
        
           <div className="navigation">
            <Link to="/TestCompleted" style={{textDecoration:"none"}}>
            <div className='final_qutn_desc'>
           <p> You have now completed all the questions and the final essay question.
Please click the below to submit your responses. 
Your responses will be evaluated and you will receive your results within 48 hours.</p>
</div>
            <div className="submit_button_div">
            <button className="submit_button" style={{backgroundColor:"#66266B"}}>Submit Exam </button>
            </div>
            </Link>
          </div>
        
        </div>

                </div>

        
               
      

    </>
    );
};
export default KExam






