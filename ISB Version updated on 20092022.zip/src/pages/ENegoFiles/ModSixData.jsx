const ModSixData = {
    ModSixData: [
      {
        id: 1,
        img:"./images/Polygon.png",
        title: "Lying on Negotiations",
        score:"_/45",
        lessionstatus:""
      },
      {
        id: 2,
        img:"./images/PolygonPurp.png",
        title: "Detecting lies while Negotiating",
         score:"_/450",
        lessionstatus:""
      },
      
      {
        id: 3,
        img:"./images/PolygonPurp.png",
        title: "Quiz",
         score:"_/100",
        lessionstatus:""
      },
     
      {
        id: 4,
        img:"./images/PolygonPurp.png",
        title: "Reading Materials",
         score:"_/100",
        lessionstatus:"Start Lession"
      },
    
    
    ]
    }
    export default ModSixData
    