const ModTwoData = {
    ModTwoData: [
      {
        id: 1,
        img:"./images/Polygon.png",
        title: "General Concepts of Distributive Negotiations",
        score:"_/10",
        lessionstatus:""
      },
      {
        id: 2,
        img:"./images/PolygonPurp.png",
        title: "Strategies of Distributive Negotiations",
         score:"_/100",
        lessionstatus:"Restart Lession"
      },
      {
        id: 3,
        img:"./images/PolygonPurp.png",
        title: "Roleplay Activity on ISB.Town",
         score:"_/45",
        lessionstatus:""
      },
      {
        id: 4,
        img:"./images/PolygonPurp.png",
        title: "Quiz",
         score:"_/100",
        lessionstatus:""
      },
      {
        id: 5,
        img:"./images/PolygonPurp.png",
        title: "Reflection on Distributive Negotiations Activity",
         score:"_/45",
        lessionstatus:""
      },
      {
        id: 6,
        img:"./images/PolygonPurp.png",
        title: "Reading Materials",
         score:"_/100",
        lessionstatus:"Start Lession"
      },
    
    
    ]
    }
    export default ModTwoData
    