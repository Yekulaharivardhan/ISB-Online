const ModFourData = {
    ModFourData: [
      {
        id: 1,
        img:"./images/Polygon.png",
        title: "Introduction to Disputes",
        score:"_/10",
        lessionstatus:""
      },
      {
        id: 2,
        img:"./images/PolygonPurp.png",
        title: "Dispute Resolution Procedures",
         score:"_/100",
        lessionstatus:"Restart Lession"
      },
      {
        id: 3,
        img:"./images/PolygonPurp.png",
        title: "Quiz",
         score:"_/45",
        lessionstatus:""
      },
      {
        id: 4,
        img:"./images/PolygonPurp.png",
        title: "Reading Materials",
         score:"_/100",
        lessionstatus:""
      },
      
    
    
    ]
    }
    export default ModFourData
    