const ModZeroData = {
    ModZeroData: [
      {
        id: 1,
        img:"./images/Polygon.png",
        title: "Welcome Note",
        score:"_/10",
        lessionstatus:""
      },
      {
        id: 2,
        img:"./images/PolygonPurp.png",
        title: "Meet the Faculty",
         score:"_/100",
        lessionstatus:"Restart Lession"
      },
      {
        id: 3,
        img:"./images/PolygonPurp.png",
        title: "Course Introduction",
         score:"_/45",
        lessionstatus:"Start Lession"
      },
      {
        id: 4,
        img:"./images/PolygonPurp.png",
        title: "How to earn your certificate",
         score:"_/100",
        lessionstatus:""
      },
      {
        id: 5,
        img:"./images/PolygonPurp.png",
        title: "How do get help from the community",
         score:"_/45",
        lessionstatus:""
      },
      {
        id: 6,
        img:"./images/PolygonPurp.png",
        title: "Meet your classmates",
         score:"_/100",
        lessionstatus:""
      },
    
    
    ]
    }
    export default ModZeroData
    