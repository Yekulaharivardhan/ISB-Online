import React from 'react';
import ModZeroData from './ModZeroData';
import './EffectiveNego.css'



const ModuleZero = (props) => {
    return (
        <>
             <div className="progress_bar" >
    <div className="Module0 h3"><img src="./images/IncompleteCircle.png" alt="" style={{display:"flex",margin:"10px 0 -47px 0px",}}/>
        
    <div className="course_availability">Available 31 October 2022
            </div>

            <h3> Module 0 - Welcome and Course Structure</h3> 

        </div>
        
            <div className="content">
            <ul>
{ModZeroData.ModZeroData.map((zero ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">
<h5 key={zero.index}>
    <div className="im col-7">
    {zero.title}
    </div>
    <div className="im col-1 dimond_img" style={{}}>
    <img src={zero.img} alt="" style={{}} /> 
    </div>
    <p className="im col-2 score_cls" style={{}}>
    {zero.score}</p>
    <div className="im col- lession_status" style={{}}>
    <span style={{}}> {zero.lessionstatus}</span>
    </div>
    </h5>
    
    
    
    
    </div></div> 
    </>
    )})}

</ul>
   
            </div>
        </div>
    </>

    );
};

export default ModuleZero;