import React from 'react';
import ModuleZero from './ModuleZero';
import { ModuleSix } from './ModuleSix';
import { ModuleOne } from './ModuleOne';
import { ModuleTwo } from './ModuleTwo';
import { ModuleThree } from './ModuleThree';
import { ModuleFour } from './ModuleFour';
import { ModuleFive } from './ModuleFive';
import { Link } from 'react-router-dom';

const ENegoPersu = () => {
    return (
        <div>
            
<div className="progress_bar " style={{height:"180px",backgroundColor:"white",marginTop:"100px", padding:"30px"}}>
    <h3 className='desc_title'>Effective Negotiation and Persuasion </h3>
    <p className="enego_first_page_desc">Course Description: Negotiation strategies at workplace plays a critical role in managing stakeholders and enabling better coordination on work activities. In this course, Prof. Nikhil Madan, will help you understand what a negotiation is and why we negotiate in required situations. This course covers two party distributive negotiations and integrative negotiations, dispute resolution, dealing with lying in negotiations and building trust in negotiations.</p>
</div>
<Link to='/APage' style={{textDecoration:"none", color:"black"}}>
<ModuleZero/>
<ModuleOne/>
<ModuleTwo/>
<ModuleThree/>
<ModuleFour/>
<ModuleFive/>
<ModuleSix/>
</Link>
        </div>
    );
};

export default ENegoPersu;