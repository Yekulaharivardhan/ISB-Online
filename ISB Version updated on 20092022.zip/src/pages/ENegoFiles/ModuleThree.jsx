import React from 'react';
import ModThreeData from './ModThreeData';



export function ModuleThree() {
   
return (
    <>
    <div className="progress_bar" >
    <div className="Module0 h3"><img src="./images/FullCircle.png" alt="" style={{display:"flex",margin:"10px 0 -47px 0px",}}/>
       
        
        
            <h3> Module 3: Integrative Negotiations</h3>
        </div>
       
            <div className="content">
            <ul>
{ModThreeData.ModThreeData.map((three ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">
<h5 key={three.id}>
    <div className="im col-7">
    {three.title}
    </div>
    <div className="im col-1 dimond_img" style={{}}>
    <img src={three.img} alt="" style={{}} /> 
    </div>
    <p className="im col-2 score_cls" style={{}}>
    {three.score}</p>
    <div className="im col-2 lession_status" style={{}}>
    <span style={{}}> {three.lessionstatus}</span>
    </div>

     </h5>
    </div></div> 
    </>
    )})}

</ul>
   
            </div>
        
</div>
</>

    );
};

