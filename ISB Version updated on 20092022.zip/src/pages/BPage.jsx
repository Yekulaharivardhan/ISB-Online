import React from "react";
import { Link } from "react-router-dom";

export default class BPage extends React.Component {
  render() {
    return (
      <div className="page-container page">
      <div className="about-page inner-container">
        <div className="container">
        <div className="mycontainer_cls">
            
            <h3 className="distrbtv_nego_titles" >Learning Objectives</h3>
            
            <p>
            Does your work involve collaborating with people from either different levels, geographical locations, or functions/ areas of expertise? What approaches have you found helpful to make it efficient? 
            </p>
          
          <div className="input_container">
            <textarea type="text" />
          </div></div>
         
          <div className="navigation" style={{ paddingTop:"20px", }}>
            <Link to="/CPage">
            <button className="submit_button" >Next <img src="./images/downarrow.png" alt="" /></button>
            
            </Link>
            <span><p><img src="./images/star.png" alt="" /> 1 Point</p></span>
          </div>
          </div></div>
      </div>
    );
  }
}
