import { Link } from "react-router-dom";


import React from 'react';

const GPage = () => {
    return (
        <>
      
      <div className="page-container page">
      <div className="about-page inner-container">
        <div className="container drag_drop_submit_btn_cls" 
        // style={{width:"850px",margin:"auto", padding:"20px",marginTop:"80px",}} 
        >
         <div className="mycontainer_cls">
            
            <h5 className="" >Classify the following characteristics as System I or System II (Drag and Drop)</h5>
            
            <p>Drag and drop the cards into the bigger boxes to categorise the options into the groups. Once you have dragged and dropped all the cards, you can submit to see your score.</p></div>
        <strong> <p>Drag these cards:</p></strong>

<div className="dragable_boxes" >
<div className="indiv_box"><img src="./images/dots.svg" alt="" />Controlled</div>
<div className="indiv_box"><img src="./images/dots.svg" alt="" />Effortless</div>
<div className="indiv_box"><img src="./images/dots.svg" alt="" /> Fast</div>

</div>

<strong>
    <p style={{marginTop:"15px"}}>Into the boxes below:</p>
</strong>
<div className="think_box_container">
<div className="think_box">
    <strong>  <p>System 1 Thinking</p></strong>
    <div className="drop_location">

    <div className="indiv_box">
    {/* <img src="./images/dots.svg" alt="" />  */}
    Fast</div>
<div className="indiv_box">
{/* <img src="./images/dots.svg" alt="" />  */}
Controlled</div>
    </div>
    
</div>
<div className="think_box">
<strong><p>System 2 Thinking</p></strong>
<div className="drop_location">
<div className="indiv_box">
{/* <img src="./images/dots.svg" alt="" /> */}
 RuleGoverned</div>
<div className="indiv_box">
{/* <img src="./images/dots.svg" alt="" /> */}
 Effortless</div>
</div>
</div>

</div>
<p>1 Point for each Correct Response. The average score was 3.5/4.0</p>

</div>
        
        <div className="navigation">
            <Link to="./AAStartExam">
            <div className="submit_button_div">
            <button className="submit_button" style={{backgroundColor:"#66266B"}}>Complete Lesson <img src="./images/rightarrow.png" alt="" /> </button>
            
            </div>
            </Link>
          </div>
           </div>
        </div>
      </>
    );
};

export default GPage;
