import { useLocation } from 'react-router-dom';
const APP = () => {
    const [mystate, setMystate] = useState(location);

    return (
        
        
        
        <h1>fgh</h1> );
  }
   
  export default APP;