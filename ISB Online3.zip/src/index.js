import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

import 'mdb-react-ui-kit/dist/css/mdb.min.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./MainPageComponents/Layout";
import Home from "./MainPageComponents/Home";
import ManagingStakeholders from "./MainPageComponents/ManagingStakeholders";
import LoginPage from "./MainPageComponents/LoginPage";
import NoPage from "./MainPageComponents/NoPage";
import 'bootstrap/dist/css/bootstrap.min.css';
import EffectiveNego from './MainPageComponents/LearnerFlowComponents/EffectiveNego';
import OnlineApplication from './MainPageComponents/OnlineApplication';
import OnlineAppPartTwo from './MainPageComponents/OnlineAppPartTwo';


export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="ManagingStakeholders" element={<ManagingStakeholders />} />
          <Route path="LoginPage" element={<LoginPage />} />
          <Route path="OnlineApplication" element={<OnlineApplication/>}/>
          <Route path="EffectiveNego" element={<EffectiveNego/>} />
          <Route path="OnlineAppPartTwo" element={<OnlineAppPartTwo />} />
          <Route path="*" element={<NoPage />} />

          
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  
    <App />
 
);
