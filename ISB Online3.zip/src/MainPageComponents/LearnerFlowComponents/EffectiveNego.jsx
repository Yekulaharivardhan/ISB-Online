import React from 'react';
import LandNavbar from '../LandingPage/LandNavbar';
import './EffectiveNego.css'
import WelcomeCourseimg from '../LandingPage/WelcomeCourseimg';
import { ModuleOne  } from './ModuleOne';
import {ModuleTwo} from './ModuleTwo'



const IndivModules = ["Module 0 - Welcome and Course Structure","Module 1: Introduction","Module 2: Distributive Negotiations","Module 3: Integrative Negotiations","Module 4: Dispute Resolution Negotiations","Module 5: Team Negotiations","Module 6: Lying on Negotiations"]

const Moduletxt = ["Welcome Note"," Meet the Faculty", "Course Introduction", "How to earn your certificate","How do get help from the community","Meet your classmates",]

const EffectiveNego = () => {
    return (
        <>
         <LandNavbar/>

<div className="container">
         <WelcomeCourseimg/>
    <h1 className='welcm_to_isb'style={{ position:"absolute", zIndex:"1", margin:"5px"}}>Effective Negotiation and Persuasion</h1>
        <div className="container" style={{marginTop:"30px"}} >
       <div className="effective_nego">

<h3>Effective Negotiation and Persuasion </h3>
<acticle>
<span style={{color:"#727783"}}>Course Description:</span> Negotiation strategies at workplace plays a critical role in managing stakeholders and enabling better coordination on work activities. In this course, Prof. Nikhil Madan, will help you understand what a negotiation is and why we negotiate in required situations. This course covers two party distributive negotiations and integrative negotiations, dispute resolution, dealing with lying in negotiations and building trust in negotiations.
</acticle>
</div>
        
{IndivModules.map((Im) =>{return(<div className="Module0">
<h3>{Im}</h3>



</div>)})}
<ModuleTwo/>
{/* <div className="Module0"> */}
<ModuleOne/>

    {/* <h3>Module 0 - Welcome and Course Structure</h3> */}



{/* <ul>
{Moduletxt.map((m ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">
    <h5 key={m}>{m}</h5>
    </div></div> 
    </>
    )})}

</ul> */}





</div>
</div>

        </>
    );
};

export default EffectiveNego;