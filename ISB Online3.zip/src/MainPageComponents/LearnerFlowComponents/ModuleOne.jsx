import React from 'react';
import useCollapse from 'react-collapsed';


const Moduletxt = ["Welcome Note"," Meet the Faculty", "Course Introduction", "How to earn your certificate","How do get help from the community","Meet your classmates",]
const lorem50= ("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione consequatur a non amet eaque quis ut commodi exercitationem aperiam, molestias quia eum doloribus, similique tenetur culpa nostrum accusamus at dolor alias corrupti laudantium tempora aut? Quod natus cupiditate molestiae minus iste dicta iure, assumenda, dignissimos, libero quasi incidunt officiis sint.")
const C= (<i className="fa-solid fa-chevron-up"></i>)
const E = (<i className="fa-solid fa-chevron-down"></i>)


export function ModuleOne() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="h3">
        <div className="header" {...getToggleProps()}>
        
            {isExpanded ? C : E }
            <strong> Module 0 - Welcome and Course Structure</strong>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            <ul>
{Moduletxt.map((m ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">
    <h5 key={m}>{m}</h5>
    </div></div> 
    </>
    )})}

</ul>
   
            </div>
        </div>
    </div>

</>

    );
};


// ===================================Two======================

