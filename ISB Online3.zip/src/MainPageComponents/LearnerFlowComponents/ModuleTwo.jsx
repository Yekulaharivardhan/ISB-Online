import React from 'react';
import useCollapse from 'react-collapsed';


const Moduletxt = ["General Concepts of Distributive Negotiations"," Strategies of Distributive Negotiations", "Roleplay Activity on ISB.Town", "Quiz","Reflection on Distributive Negotiations Activity","Reading Materials",]

const C= (<i className="fa-solid fa-chevron-up"></i>)
const E = (<i className="fa-solid fa-chevron-down"></i>)




// ===================================Two======================


export function ModuleTwo() {
    const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();
return (
    <>
    <div className="h3">
        <div className="header" {...getToggleProps()}>
        
            {isExpanded ? C : E }
            <strong> Module 2: Distributive Negotiations</strong>
        </div>
        <div {...getCollapseProps()}>
            <div className="content">
            <ul>
{Moduletxt.map((m ) => { return( 
    <> 
<div className="module_nav_main">
<div className="module_navs">
    <h5 key={m}>{m}</h5>
    </div></div> 
    </>
    )})}

</ul>
   
            </div>
        </div>
    </div>

</>

    );
};

