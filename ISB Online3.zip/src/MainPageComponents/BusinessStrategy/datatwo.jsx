

const datatwo ={
productdata: [
    {
        id: 1,
        img:"./images/effectiveCommunication.jpg",
        title: "Economics for Managgement",
        desc: "Leading People and Change is a course designed to develop and expand the essential knowledge, skills, and mindset required to lead people and teams effectively. The course will help you to learn skills required for stakeholder engagement, and techniques to drive high-performing teams and deal with change. You will be able to manage conflict and change, delegate and collaborate effectively, and empathize and influence others..",
        durtnweeks:"5 Weeks",
        durtnhrsperweek:"7-8 hours per week",
        price: 30000,
    },
    {
        id: 2,
        img:"./images/negotiation.jpg",
        title: "Strategy Formulation and...",
        desc: "Leading People and Change is a course designed to develop and expand the essential knowledge, skills, and mindset required to lead people and teams effectively. The course will help you to learn skills required for stakeholder engagement, and techniques to drive high-performing teams and deal with change. You will be able to manage conflict and change, delegate and collaborate effectively, and empathize and influence others..",
        durtnweeks:"2 Weeks",
        durtnhrsperweek:"5-6 hours per week",
        price: 5000,
    },
    
    {
        id: 3,
        img:"./images/effectiveCommunication.jpg",
        title: "Driving Growth and innovation",
        desc: "The Accounting Fundamentals course contains basic theory, concepts, and principles of financial accounting. Professor Hariom Manchiraju will help you gain a sound understanding of the technical skills needed to analyze and understand common financial statements such as the income statement and balance sheet. The interpretation of the informational content of these financial statements and their relevance to decision making will be...Learn more",
        durtnweeks:"1 Weeks",
        durtnhrsperweek:"5-6 hours per week",
        price: 30000,
    },
    
]
}
export default datatwo;