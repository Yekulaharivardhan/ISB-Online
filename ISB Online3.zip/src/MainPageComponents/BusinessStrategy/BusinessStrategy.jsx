import React, { useState } from 'react';
import Carousel from 'react-bootstrap/Carousel';
import CoursesCards from '../LandingPage/CoursesCards';
import CardMain from './../LandingPage/CardMain';
import '../LandingPage/JoinOurCourse.css'
import './BusinessStrategy.css'

function BusinessStrategy() {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  };

  return (
    <Carousel activeIndex={index} onSelect={handleSelect}>
      <Carousel.Item>
        <h3 className='join_our_crs'>Business Strategy</h3>

<CardMain style={{width:"15rem"}}/>


        <Carousel.Caption>
          
          
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <h3 className='join_our_crs'>Marketing Learning Track</h3>
<CardMain style={{width:"15rem"}}/>
        <Carousel.Caption>
          
         
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <h3 className='join_our_crs'>Marketing Learning Track</h3>
<CardMain style={{width:"15rem"}}/>
        <Carousel.Caption>
          
         
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}


export default BusinessStrategy;