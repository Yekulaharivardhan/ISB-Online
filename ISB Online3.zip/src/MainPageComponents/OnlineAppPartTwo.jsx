import React from 'react';
import LandNavbar from './LandingPage/LandNavbar';
import { Container } from 'react-bootstrap';


const polYgon = (<div className="polygon_cls">
<svg height="75" width="245">
<polygon points="220,20 290,210 160,210" />
Sorry, your browser does not support inline SVG.
</svg>
</div>)


var video = document.querySelector("#web_cam");

if (navigator.mediaDevices.getUserMedia) {
  navigator.mediaDevices.getUserMedia({ video: true, audio:true })
    .then(function (stream) {
      video.srcObject = stream;
      video.current.autoplay = true;
                
    })
    .catch(function (error) {
      console.log("Something went wrong!");
    });
}


const OnlineAppPartTwo = () => {
    return (
        <>
        <LandNavbar/>
      <div className="container" style={{marginTop:"130px"}}>
      
      <div className="online_applictn_form_p1">
    <h3>ISBOnline Application Form - Part 2/2</h3>
    <p>In this section, you will need to record an introduction video, and optionally submit a recording of your name to assist  others in pronoucning your name. 
If you are having any issues in recording, please visit our System Checklist and support page here. </p>
<input type="button" className='btn btn-primary col-2' value="System Checklist" style={{ backgroundColor:"#057092", border:"#057092",height:"40px", borderRadius:"0px", marginBottom:"20px"}}/>
<p className="">Once you have recorded yourself online, you can submit your application. This application is saved as a draft until you click submit. If the draft is not submitted within 30 days, it will be deleted.</p>
</div>


<div className="container form_field_container_cls">
<div className="video_cls" style={{justifyContent:"center", display:"flex"}}>
<video id='web_cam' className="col-12" height="475" controls >
<source src="" type="video/mp4"/>
  <source src="" type="video/ogg"/>
</video>
</div>


<div className="video_button_cls">
<input type="button" className='btn btn-primary' value="Start Recording" style={{ backgroundColor:"#057092", border:"#057092",height:"40px", borderRadius:"0px", marginBottom:"20px", marginRight:"10px"}}/>
<input type="button" className='btn btn-primary' value="Play Video" style={{ backgroundColor:"#66266B", border:"#66266B",height:"40px", borderRadius:"0px", marginBottom:"20px"}}/>
</div>
</div>


<div className="container form_field_container_cls" >

  <h3>Subscribe to ISB Updates</h3>
  <p className="">You may also subscribe to additional email notifications from ISB for upcoming programs and relevant events. Note this is optional and you can unsubscribe at any time.</p>
  <br/>
  <p className="">Yes, keep me updated to upcoming ISB programs and events</p>
  <div className="prgrs_bar progress-bar-success col-12" style={{height:"40px", backgroundColor:"gray", marginBottom:"15px"}}></div>
  <input type="button" className='btn btn-primary' value="Start/Stop Recording" style={{ backgroundColor:"#057092", border:"#057092",height:"40px", borderRadius:"0px", marginBottom:"20px", marginRight:"10px"}}/>
<input type="button" className='btn btn-primary' value="Play Video" style={{ backgroundColor:"#66266B", border:"#66266B",height:"40px", borderRadius:"0px", marginBottom:"20px"}}/>
</div>



<div className="container footer_btn_cls">
<input type="button" className='btn btn-primary' value="Back to Part 1" style={{ backgroundColor:"gray"}}/>
<input type="button" className='btn btn-primary' value="Submit Application" style={{ backgroundColor:"#66266B"}}/>
</div>


<div className="container">
<div className="circlre_two">
  <p className="admission_scrn_circle">Click here to view the Admin Admission Screen</p>
  <div className="stripes"></div>
  <div className="stripes2"></div>
  </div>
  <div class="pokerchip blue ">
  </div>
</div>








</div>
</>
     
    );
};

export default OnlineAppPartTwo;