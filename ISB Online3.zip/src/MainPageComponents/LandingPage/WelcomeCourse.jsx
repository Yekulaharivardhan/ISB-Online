import React from 'react';
import "./welcomeHome.css"
// import './LandNavbar.css'
import { Container } from 'react-bootstrap';
import WelcomeCourseimg from './WelcomeCourseimg';

const WelcomeCourse = () => {
    return (
        <div className="container">
        
        
        
        
    <div className='isb_welcome_and_img' style={{ }}>
    <WelcomeCourseimg/>
    <h1 className='welcm_to_isb'style={{ position:"absolute", zIndex:"1"}}>Welcome to ISB Online</h1>
    
    </div>
        </div>
        
    );
};

export default WelcomeCourse;