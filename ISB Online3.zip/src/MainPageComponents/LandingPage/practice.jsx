import './practice.css'

const Practice = () => {
    return ( 

<div>
<div className="flexbox-container">
<div className="flexbox-item flexbox-item-1">Harivardhan</div>
<div className="flexbox-item flexbox-item-2">Harivardhan</div>
<div className="flexbox-item flexbox-item-3">Harivardhan</div>


</div>  
</div>

     );
}
 
export default Practice;